# ========================================
# Enrique Acosta
# October 2009
#
# Kepler equation solver
#
# INPUTS:         M   The mean anomaly
#                       ecc   The eccentricity
#                       n   The number of steps to iterate newtons method
#
# OUTPUTS:      E   The Eccentric anomaly, solution to Keplers equation
#                           E - e sin(E) = M
#
# METHOD        Newtons method
# ========================================

from math import *

# ------------------------------------------------------------
# sign function

def sign(a):
    if a==0:
        return 0
    else:
        return abs(a)/a

# ------------------------------------------------------------
# Newton method

def KeplerSolve(M,ecc,n):
    E=M+0.85*sign(sin(M))

    for i in range(n):
        E=E-(E-ecc*sin(E)-M)/(1-ecc*cos(E))
    return E

    
    

    
    
