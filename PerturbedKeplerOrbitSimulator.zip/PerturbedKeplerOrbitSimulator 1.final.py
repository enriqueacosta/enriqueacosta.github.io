# ========================================
# Enrique Acosta
# October 2009
#
# PerturbedKeplerOrbitSimulator v 1.0
#
# INPUTS:         a            Semiamplitude
#               ecc           The eccentricity
#                 n           mean motion
#                m1           mass1
#                m2            mass2
#         TimeRange           Amount of time of simulation
#                r0           Initial position (vector)
#                v0           Initial velociy (vector)
#               rho            Position vector of the planet m2 with respect to the star m1
#
# OUTPUTS:      [x,y]   the new x and y are the position vectors of the particle at each time step.
#                          
#
# METHOD        Use the f and g functions
#
# COMMENTS    it calculation
#             The orbit of the planet is computed at the end of the computation.
# ========================================

from KeplerSolve import *
from math import *
from pylab import *


# ------------------------------------------------------------
# Inputs
a=0.8
ecc=0.0
TimeRange=120
m1=1.0
# m2 set to zero for to check ALGORITHM!!!
m2=0.00001
rho=[1,0]


# ------------------------------------------------------------
# Initializations
# NOTE: The mu of the elliptical orbit is m1 since the particle is massless

mu1=m1/(m1+m2)
mu2=m2/(m1+m2)
mu=m1
Norm_rho=sqrt(rho[0]**2+rho[1]**2)
r0=[a,0]
Norm_r0=sqrt(r0[0]**2+r0[1]**2)

# Initial velocity vector assuming initial circular motion which is aligned
# Note: the parameter used here is mu

C=-float(mu)/(2*a)
vInit=sqrt(2*(C+float(mu)/Norm_r0))
v0=[0,vInit]

# initial n
n=sqrt(mu/a**3)

# initializations of the output vectors
rx=[]
ry=[]
px=[]
py=[]

# ------------------------------------------------------------
# Cumputation Bounds

N=1000           #the number of time steps of the simulation
k=50              #the number of iterations used in the kepler solution
DeltaT=float(TimeRange)/N

# ------------------------------------------------------------
# The simulation

# Take E0=0 (see 2.41 in the book)
E0=0.0

# M0
M0=E0-ecc*sin(E0)

M=n*DeltaT/2-M0
E=KeplerSolve(M,ecc,k)
f=(a/Norm_r0)*(cos(E-E0)-1)+1
g=DeltaT/2+(1/n)*(sin(E-E0)-(E-E0))

for i in range(N):
    # -----------------------------------------
    # Half step (with the previous elements)
    
    r=[f*r0[0]+g*v0[0],f*r0[1]+g*v0[1]]
    Norm_r=sqrt(r[0]**2+r[1]**2)
  
    fdot=-a**2*n*sin(E-E0)/(Norm_r*Norm_r0)
    gdot=a*(cos(E-E0)-1)/Norm_r +1

    v=[fdot*r0[0]+gdot*v0[0],fdot*r0[1]+gdot*v0[1]]

    # -----------------------------------------
    # Kick
    
    rMimusRho=[r[0]-rho[0],r[1]-rho[1]]
    Norm_rMimusRho=sqrt(rMimusRho[0]**2+rMimusRho[1]**2)
    kick=[-mu2*(rMimusRho[0]/Norm_rMimusRho**3-rho[0]/Norm_rho**3),
          -mu2*(rMimusRho[1]/Norm_rMimusRho**3-rho[1]/Norm_rho**3)]
    v[0]=v[0]+kick[0]
    v[1]=v[1]+kick[1]
    
    Norm_v=sqrt(v[0]**2+v[1]**2)
    
    # -----------------------------------------
    # Computation of new elements

    # a
    C=Norm_v**2/2 -mu/Norm_r
    a=-mu/(2*C)

    # n
    n=sqrt(mu/a**3)

    # h
    hSquared=(r[0]*v[1]-r[1]*v[0])**2

    # ecc
    oldecc=ecc
    ecc=sqrt(abs(1-hSquared/(mu*a)))
    if abs(oldecc-ecc)>0.1:
        print(abs(oldecc-ecc))
        print("Eccentricity Blow",oldecc,ecc,i)
        break

    # E0
    #print(r[0]/a +ecc)
    #print(acos(r[0]/a +ecc))
    #E0=acos(r[0]/a +ecc)
    
##        E0=acos((1-Norm_r/a)/ecc)
##        print(Norm_r/a)
##        print(ecc)
##        print((1-Norm_r/a)/ecc)
##        print(E0)
        
    # M0
    M0=E0-ecc*sin(E0)

    # M
    M=n*DeltaT/2-M0

    # E
    E=KeplerSolve(M,ecc,k)
    
    # -----------------------------------------
    # Next Half Step
          
    r0=r
    v0=v
    Norm_r0=Norm_r

    f=(a/Norm_r0)*(cos(E-E0)-1)+1
    g=DeltaT/2+(1/n)*(sin(E-E0)-(E-E0))
    
    r=[f*r0[0]+g*v0[0],f*r0[1]+g*v0[1]]
    Norm_r=sqrt(r[0]**2+r[1]**2)
    
    fdot=-a**2*n*sin(E-E0)/(Norm_r*Norm_r0)
    gdot=a*(cos(E-E0)-1)/Norm_r +1

    v=[fdot*r0[0]+gdot*v0[0],fdot*r0[1]+gdot*v0[1]]

##    if Norm_r>1:
##        print("NormBlow. i=",i)
##        rx.pop()
##        ry.pop()
##        break
##    print(Norm_r,Norm_r0,ecc,oldecc)
    
    # -----------------------------------------
    # Append The new info

    rx.append(r[0])
    ry.append(r[1])

##    change=(rx[len(rx)-1]-rx[len(rx)-2])**2+(ry[len(ry)-1]-ry[len(ry)-2])**2
##    if change>1:
##        rx.pop()
##        ry.pop()
##        print('break!')
##        break
    
    

    # -----------------------------------------
    # Move the planet
    rho=[cos(M-M0)*rho[0]-sin(M-M0)*rho[1],sin(M-M0)*rho[0]+cos(M-M0)*rho[1]]
    px.append(rho[0])
    py.append(rho[1])


# ------------------------------------------------------------
# Draw the graph

figure()
plot(rx+px,ry+py)
show()


    
