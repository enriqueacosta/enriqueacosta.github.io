# ========================================
# Enrique Acosta
# ========================================

import math, pylab

# ------------------------------------------------------------
# Initial parameter values for the masses and stepsize

# MassPlanet/MassStar will vary over the interval
# (10^(MinimumLogMass), 10^(MaximumLogMass))

MinimumLogMass=-9
MaximumLogMass=-3
LogMassStepSize=0.5

# ------------------------------------------------------------
# Initialization of the MassPlanet/MassStar list

MassPlanetOverMassStar=[]
LogMassPlanetOverMassStar=[]
t=MinimumLogMass
while t <= MaximumLogMass:
    MassPlanetOverMassStar.append(10**(t))
    LogMassPlanetOverMassStar.append(t)
    t=t+LogMassStepSize

# ------------------------------------------------------------
# Computation of DeltaA

DeltaA=[]

for i in LogMassPlanetOverMassStar:
    #Creation of temporaty DeltaA for plot check
    DeltaA.append(i**2)
    # DeltaA.append(ComputeDeltaA(i))
    
pylab.figure()
pylab.plot(LogMassPlanetOverMassStar,DeltaA)
pylab.show()
    


 
 

 
