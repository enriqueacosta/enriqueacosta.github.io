# ========================================
# Enrique Acosta
# October 2009
#
# PerturbedKeplerOrbitSimulator v.2
#
# INPUTS:         a            Semiamplitude
#                       ecc           The eccentricity
#                       n           mean motion
#                     m1           mass1
#                     m2            mass2
#         TimeRange           Amount of time of simulation
#                      r0           Initial position (vector)
#                      v0           Initial velociy (vector)
#                    rho            Position vector of the planet m2 with respect to the star m1
#
# OUTPUTS:      [x,y]   the new x and y are the position vectors of the particle at each time step.
#                          
#
# METHOD        Use the f and g functions
# ========================================

from KeplerSolve import *
from math import *
from pylab import *


# ------------------------------------------------------------
# Inputs
# Nice settings: a=0.4, RimeRange=10, m2=0.0001
a=0.6
ecc=0.0
TimeRange=20
m1=1.0
# m2 set to zero for to check ALGORITHM!!!
m2=0.000
rho=[1,0]


# ------------------------------------------------------------
# Initializations
# NOTE: The mu of the elliptical orbit is m1 since the particle is massless

mu1=m1/(m1+m2)
mu2=m2/(m1+m2)
mu=m1
Norm_rho=sqrt(rho[0]**2+rho[1]**2)
r0=[a,0]
Norm_r0=sqrt(r0[0]**2+r0[1]**2)

muPlanet=m1+m2
aPlanet=1.0
nPlanet=sqrt(muPlanet/aPlanet**3)
r0planet=[aPlanet,0]

# Initial velocity vector assuming initial circular motion which is aligned
# Note: the parameter used here is mu

C=-float(mu)/(2*a)
vInit=sqrt(2*(C+float(mu)/Norm_r0))
v0=[0,vInit]

# initial n
n=sqrt(mu/a**3)

# initializations of the output vectors
rx=[]
ry=[]
px=[]
py=[]

# ------------------------------------------------------------
# Cumputation Bounds

N=1000           #the number of time steps of the simulation
k=50              #the number of iterations used in the kepler solution
DeltaT=float(TimeRange)/N

# ------------------------------------------------------------
# The simulation

# Take E0=0 (see 2.41 in the book)
E0=0.0

# M0
M0=E0-ecc*sin(E0)

M=n*DeltaT/2-M0
E=KeplerSolve(M,ecc,k)
f=(a/Norm_r0)*(cos(E-E0)-1)+1
g=DeltaT/2+(1/n)*(sin(E-E0)-(E-E0))

Mplanet=0.0

# Move the planet half a step
Mplanet=nPlanet*DeltaT/2
rho=[cos(Mplanet)*r0planet[0]-sin(Mplanet)*r0planet[1],
     sin(Mplanet)*r0planet[0]+cos(Mplanet)*r0planet[1]]
px.append(rho[0])
py.append(rho[1])

for i in range(N):
    # -----------------------------------------
    # Half step (with the previous elements)
    
    r=[f*r0[0]+g*v0[0],f*r0[1]+g*v0[1]]
    Norm_r=sqrt(r[0]**2+r[1]**2)
  
    fdot=-a**2*n*sin(E-E0)/(Norm_r*Norm_r0)
    gdot=a*(cos(E-E0)-1)/Norm_r +1

    v=[fdot*r0[0]+gdot*v0[0],fdot*r0[1]+gdot*v0[1]]

    # -----------------------------------------
    # Kick
    
    rMimusRho=[r[0]-rho[0],r[1]-rho[1]]
    Norm_rMimusRho=sqrt(rMimusRho[0]**2+rMimusRho[1]**2)
    kick=[-mu2*(rMimusRho[0]/Norm_rMimusRho**3-rho[0]/Norm_rho**3),
          -mu2*(rMimusRho[1]/Norm_rMimusRho**3-rho[1]/Norm_rho**3)]
    v[0]=v[0]+kick[0]
    v[1]=v[1]+kick[1]
    
    Norm_v=sqrt(v[0]**2+v[1]**2)
    
    # -----------------------------------------
    # Computation of new elements

    # a
    C=Norm_v**2/2 -mu/Norm_r
    a=-mu/(2*C)
    if a<0:
        print("Negative a",a)
        break

    # n
    n=sqrt(mu/a**3)

    # h
    hSquared=(r[0]*v[1]-r[1]*v[0])**2

    # ecc
    oldecc=ecc
    ecc=sqrt(abs(1-hSquared/(mu*a)))
    if abs(ecc)<0.0000001:
        ecc=0
    else:
        print("ecc override not done")

    # set change in eccentricity which breaks loop
    if abs(oldecc-ecc)>0.1:
        print("Eccentricity Blow! Change:",abs(oldecc-ecc),i)
        break

    # E0
    temp=r[0]/a + ecc
    if abs(abs(temp)-1)<0.1:
        temp=1.0
    else:
        print("temp override not done",temp,i)
    temp=sign(temp)*min(1,abs(temp))
    E0=acos(temp)
    #print(E0)
    if temp==0.0:
        break
    # Uncomment below to override the computation of E0
    #E0=0.0
    
    # M0
    M0=E0-ecc*sin(E0)
    #print(M0)

    # M
    M=n*DeltaT/2-M0

    # E
    E=KeplerSolve(M,ecc,k)
    print(E-E0)
    
    # -----------------------------------------
    # Next Half Step
          
    r0=r
    v0=v
    Norm_r0=Norm_r

    f=(a/Norm_r0)*(cos(E-E0)-1)+1
    g=DeltaT/2+(1/n)*(sin(E-E0)-(E-E0))
    
    r=[f*r0[0]+g*v0[0],f*r0[1]+g*v0[1]]
    Norm_r=sqrt(r[0]**2+r[1]**2)

    if Norm_r!=Norm_r:
        print("Normr is nan",Norm_r)
        break
    
    fdot=-a**2*n*sin(E-E0)/(Norm_r*Norm_r0)
    gdot=a*(cos(E-E0)-1)/Norm_r +1

    v=[fdot*r0[0]+gdot*v0[0],fdot*r0[1]+gdot*v0[1]]

    # -----------------------------------------
    # Prepare r0 and v0 for the next step in the iteration

    r0=r
    v0=v
    Norm_r0=Norm_r

    # -----------------------------------------
    # Move the planet One step (to a the next step an a half)
    Mplanet=Mplanet+nPlanet*DeltaT
    rho=[cos(Mplanet)*r0planet[0]-sin(Mplanet)*r0planet[1],
     sin(Mplanet)*r0planet[0]+cos(Mplanet)*r0planet[1]]
    px.append(rho[0])
    py.append(rho[1])

    
    # -----------------------------------------
    # Append The new info for the graph

    rx.append(r[0])
    ry.append(r[1])


# ------------------------------------------------------------
# Draw the graph

figure()
plot(rx+px,ry+py)
show()


    
