# ========================================
# Enrique Acosta
# October 2009
#
# PerturbedKeplerOrbitSimulator v. 4
#
# INPUTS:         a            Semiamplitude
#                     m2            mass2
#
# CONSTANTS:
#                    ecc           The eccentricity. Initial ecc is zero always
#                     m1           mass1. Mass1 is 1 always
#                    rho            Position vector of the planet m2 with respect to the star m1.
#               aPlanet          The semiamplitude of the planet is always 1
#         TimeRange           Amount of time of simulation = 50
#           tolerance           How different numbers have to be to change
#
# COMPUTATION BOUNDS
#                       N           The number of iterations in the loop (Number of intervals TimeRange
#                                     is split in to) 100000 necessary for TimeRange 50
#                       k           The number of iterations for the KeplerSolve function
#
# COMTUTED CONSTANTS FROM THE INPUT:
#                      r0           Initial position (vector) 
#                      v0           Initial velociy (vector) ... computed from a and m2
#                   mu1           m1/(m1+m2)
#                   mu2           m2/(m1+m2)
#                    mu           m1 (the mu of the elliptical orbit of the particle (massless)
#               muPlanet        m1+m2
#               nPlanet             The n of the planet
#               r0planet        The initial position of the planet
#
# OUTPUTS:  success         1 if loop went all the way, 0 otherwise
#                  message        description of why the loop failed
#
# Nice settings:                a=0.4, RimeRange=10, m2=0.0001
# Another:                       a=0.95, TimeRnage=4, m2=0.00000001
#
# METHOD        Use the f and g functions
#
# NEW IN THIS VERSION:
#                   -   Removed the computation of the vector for the graph to speed up.
#                       (commeted out...not deleted)
#                   -   Added tolerance constant to contro changes in the constants
#
# INSTRUCTIONS:
#                   At the end of this file is the call of the funtion with specific parameters.
# ========================================

from KeplerSolve import *
from math import *
from pylab import *

def PerturbedOrbit(a,m2):
    # ------------------------------------------------------------
    # Constants
    ecc=0.0
    m1=1.0
    rho=[1,0]
    aPlanet=1.0
    TimeRange=50
    tolerance=0.01

    # ------------------------------------------------------------
    # Initializations

    mu1=m1/(m1+m2)
    mu2=m2/(m1+m2)
    mu=m1
    
    Norm_rho=sqrt(rho[0]**2+rho[1]**2)
    
    r0=[a,0]
    Norm_r0=sqrt(r0[0]**2+r0[1]**2)

    muPlanet=m1+m2

    nPlanet=sqrt(muPlanet/aPlanet**3)
    r0planet=[aPlanet,0]

    # Initial velocity vector assuming initial circular motion which is aligned
    C=-float(mu)/(2*a)
    vInit=sqrt(2*(C+float(mu)/Norm_r0))
    v0=[0,vInit]

    hSquared=(r0[0]*v0[1]-r0[1]*v0[0])**2

    # initial n
    n=sqrt(mu/a**3)

    # initializations of the output 
    # Vectors
##    rx=[]
##    ry=[]
##    px=[]
##    py=[]

    # Output Message (if loop breaks message will change to the reason of the break)
    message="stable"

    # ------------------------------------------------------------
    # Cumputation Bounds

    N=100000         #the number of time steps of the simulation
    k=10              #the number of iterations used in the kepler solution
    DeltaT=6.28318530717958647692528*float(TimeRange)/N

    # ------------------------------------------------------------
    # The simulation

    Mplanet=0.0

    # Take E0=0 (see 2.41 in the book)
    E0=0.0

    # M0
    M0=E0-ecc*sin(E0)

    # First half step

    M=n*DeltaT/2-M0
    E=KeplerSolve(M,ecc,k)
    f=(a/Norm_r0)*(cos(E-E0)-1)+1
    g=DeltaT/2+(1/n)*(sin(E-E0)-(E-E0))

    r=[f*r0[0]+g*v0[0],f*r0[1]+g*v0[1]]
    Norm_r=sqrt(r[0]**2+r[1]**2)
      
    fdot=-a**2*n*sin(E-E0)/(Norm_r*Norm_r0)
    gdot=a*(cos(E-E0)-1)/Norm_r +1

    v=[fdot*r0[0]+gdot*v0[0],fdot*r0[1]+gdot*v0[1]]

    # Move the planet half a step
    Mplanet=nPlanet*DeltaT/2
    rho=[cos(Mplanet)*r0planet[0]-sin(Mplanet)*r0planet[1],
         sin(Mplanet)*r0planet[0]+cos(Mplanet)*r0planet[1]]
##    px.append(rho[0])
##    py.append(rho[1])

    for i in range(N):
        # -----------------------------------------
        # Kick
        
        rMimusRho=[r[0]-rho[0],r[1]-rho[1]]
        Norm_rMimusRho=sqrt(rMimusRho[0]**2+rMimusRho[1]**2)
        kick=[-mu2*(rMimusRho[0]/Norm_rMimusRho**3-rho[0]/Norm_rho**3),
              -mu2*(rMimusRho[1]/Norm_rMimusRho**3-rho[1]/Norm_rho**3)]
        v[0]=v[0]+kick[0]
        v[1]=v[1]+kick[1]
        
        Norm_v=sqrt(v[0]**2+v[1]**2)
        
        # -----------------------------------------
        # Computation of new elements

        # a
        olda=a
        C=Norm_v**2/2 -mu/Norm_r
        a=-mu/(2*C)
        if a<0:
            #print("Negative a",a)
            message="Negative a"
            break

        if abs(olda-a)<tolerance:
            a=olda  

        # n
        n=sqrt(mu/a**3)
        #print(n)

        # h
        hold=hSquared
        hSquared=(r[0]*v[1]-r[1]*v[0])**2

        if abs(hold-hSquared)<tolerance:
            hSquared=hold

        # ecc
        oldecc=ecc
        ecc=sqrt(abs(1-hSquared/(mu*a)))

        # set change in eccentricity which breaks loop
        if abs(oldecc-ecc)>0.4:
            #print("Eccentricity Blow! Change:",abs(oldecc-ecc),i)
            message="Big change in eccentricity"
            break

        if abs(oldecc-ecc)<tolerance:
            ecc=oldecc

        # E0
        temp=(r[0]/a) + ecc
        #print(temp)
        temp=sign(temp)*min(1,abs(temp))
        E0=acos(temp)
        # Figure out the correct E0 by using the sign of sin(E0) from r[1]. See 2.41 p. 33.
        if r[1]<0:
            E0=6.28318530717958647692528676655-E0
        #print(E0)
            
        # Uncomment below to override the computation of E0
        #E0=0.0
        
        # M0
        M0=E0-ecc*sin(E0)
        #print(M0)

        # M Changed the MINUS for a PLUS!
        M=n*DeltaT+M0
        #print(M)

        # E
        E=KeplerSolve(M,ecc,k)
        #print(E)
        
        # -----------------------------------------
        # Next Half Step
              
        r0=r
        v0=v
        Norm_r0=Norm_r

        f=(a/Norm_r0)*(cos(E-E0)-1)+1
        g=DeltaT+(1/n)*(sin(E-E0)-(E-E0))
        
        r=[f*r0[0]+g*v0[0],f*r0[1]+g*v0[1]]
        Norm_r=sqrt(r[0]**2+r[1]**2)

        if Norm_r!=Norm_r:
            #print("Normr is nan",Norm_r)
            message="Particle position is NaN for some reason."
            break

        if Norm_r>1.0:
            #print("Particle crossed planet's orbit")
            message="Particle crossed the planet's orbit."
            break
        
        fdot=-(a**2)*n*sin(E-E0)/(Norm_r*Norm_r0)
        gdot=a*(cos(E-E0)-1)/Norm_r +1

        v=[fdot*r0[0]+gdot*v0[0],fdot*r0[1]+gdot*v0[1]]


        # -----------------------------------------
        # Append The new info for the graph

##        rx.append(r[0])
##        ry.append(r[1])

        
        # -----------------------------------------
        # Prepare r0 and v0 for the next step in the iteration

        r0=r
        v0=v
        Norm_r0=Norm_r

        # -----------------------------------------
        # Move the planet One step (to a the next step an a half)
        
        Mplanet=Mplanet+nPlanet*DeltaT
        rho=[cos(Mplanet)*r0planet[0]-sin(Mplanet)*r0planet[1],
         sin(Mplanet)*r0planet[0]+cos(Mplanet)*r0planet[1]]
##        px.append(rho[0])
##        py.append(rho[1])

    # ------------------------------------------------------------
    # Draw the graph

##    figure()
##    plot(rx+px,ry+py)
##    show()

    # ------------------------------------------------------------
    # Return the message

    return message
    
# End of function definition


# ----------------------------------------------------
# Call the Function
result=PerturbedOrbit(0.984,0.00000001)
print("Result:",result)
    
